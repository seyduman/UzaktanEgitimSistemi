-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 08 Şub 2021, 17:23:32
-- Sunucu sürümü: 5.7.31
-- PHP Sürümü: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `phpproject`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bolumler`
--

DROP TABLE IF EXISTS `bolumler`;
CREATE TABLE IF NOT EXISTS `bolumler` (
  `bolumID` int(11) NOT NULL AUTO_INCREMENT,
  `adi` char(50) NOT NULL,
  PRIMARY KEY (`bolumID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin5;

--
-- Tablo döküm verisi `bolumler`
--

INSERT INTO `bolumler` (`bolumID`, `adi`) VALUES
(1, 'Bilgisayar Mühendisliği'),
(2, 'Elektrik-Elektronik Mühendisliği'),
(3, 'Makine Mühendisliği');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dersdosya`
--

DROP TABLE IF EXISTS `dersdosya`;
CREATE TABLE IF NOT EXISTS `dersdosya` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `dosya` text NOT NULL,
  `dersID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `dersID` (`dersID`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `dersdosya`
--

INSERT INTO `dersdosya` (`ID`, `dosya`, `dersID`) VALUES
(4, 'dosyalar/2017_2018_bilg_muh_haftalik_ders_prog_bahar_no.pdf', 2),
(5, 'dosyalar/5000135109-5000213159-1-PB.pdf', 2),
(6, 'dosyalar/Uygulama2.pdf', 2),
(15, 'dosyalar/er_diyagram.pdf', 1),
(16, 'dosyalar/Genetic_Rapor.pdf', 1),
(17, 'dosyalar/CSS_GIRIS.pdf', 4),
(18, 'dosyalar/Genetic_Rapor.pdf', 5),
(19, 'dosyalar/abc.pdf', 6),
(20, 'dosyalar/2018_2019_Proje_Dersleri_Öğrenci_Listeleri.pdf', 7),
(21, 'dosyalar/termodinamik_hm.pdf', 8),
(22, 'dosyalar/Analog_Devre_Elemanlari.pdf', 9),
(23, 'dosyalar/ders8.pdf', 4),
(24, 'dosyalar/CSS_GIRIS.pdf', 4),
(25, 'dosyalar/CSS_GIRIS.pdf', 4);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dersicerik`
--

DROP TABLE IF EXISTS `dersicerik`;
CREATE TABLE IF NOT EXISTS `dersicerik` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `baslik` varchar(50) NOT NULL,
  `icerik` varchar(200) NOT NULL,
  `dersID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `dersID` (`dersID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin5;

--
-- Tablo döküm verisi `dersicerik`
--

INSERT INTO `dersicerik` (`ID`, `baslik`, `icerik`, `dersID`) VALUES
(2, 'Hafta-1', 'C Programlama Dili Nedir', 2),
(3, 'Hafta-2', 'C programlama dilinde değişkenler', 2),
(4, 'Hafta-3', 'C programlama dili diziler', 2),
(12, 'Hafta-1', 'Flip Flop nedir?', 1),
(13, 'hafta-1', 'ABC algoritması', 6),
(14, 'hafta-1', 'Proje Listesi', 7),
(15, 'hafta-1', 'Termodinamik ve Kuralları', 8),
(16, 'hafta-1', 'Web Programlamaya Giriş', 4),
(17, 'hafta-1', 'Programlama Dili C#', 5),
(18, 'hafta-1', 'Devre Elemanları', 9),
(19, 'Hafta2', 'HTML', 4),
(20, 'css', 'css', 4),
(21, 'css', 'css', 4);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dersler`
--

DROP TABLE IF EXISTS `dersler`;
CREATE TABLE IF NOT EXISTS `dersler` (
  `dersID` int(11) NOT NULL AUTO_INCREMENT,
  `dersAdi` char(50) NOT NULL,
  `bolumID` int(11) NOT NULL,
  `kullaniciID` int(11) NOT NULL,
  `dersdurum` tinyint(1) NOT NULL,
  PRIMARY KEY (`dersID`),
  KEY `bolumID` (`bolumID`),
  KEY `yonetID` (`kullaniciID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin5;

--
-- Tablo döküm verisi `dersler`
--

INSERT INTO `dersler` (`dersID`, `dersAdi`, `bolumID`, `kullaniciID`, `dersdurum`) VALUES
(1, 'Mantık Devreleri', 1, 1, 1),
(2, 'Programlama Dili-1', 1, 1, 1),
(4, 'Web Programlama', 1, 8, 1),
(5, 'Programlama Dili-2', 1, 8, 0),
(6, 'Yapay Zeka', 1, 16, 0),
(7, 'Fizik', 3, 15, 0),
(8, 'Termodinamik', 3, 15, 0),
(9, 'Devre Elemanları', 2, 16, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kayitanahtarlari`
--

DROP TABLE IF EXISTS `kayitanahtarlari`;
CREATE TABLE IF NOT EXISTS `kayitanahtarlari` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `dersID` int(11) NOT NULL,
  `kayitAnahtari` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `dersID` (`dersID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin5;

--
-- Tablo döküm verisi `kayitanahtarlari`
--

INSERT INTO `kayitanahtarlari` (`ID`, `dersID`, `kayitAnahtari`) VALUES
(4, 2, 'emn'),
(5, 1, 'asd'),
(6, 4, 'web'),
(7, 5, 'pro1'),
(8, 6, 'pro2'),
(9, 7, 'fiz'),
(10, 8, 'ttt'),
(11, 9, 'devre'),
(12, 4, 'web');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici`
--

DROP TABLE IF EXISTS `kullanici`;
CREATE TABLE IF NOT EXISTS `kullanici` (
  `kullaniciID` int(11) NOT NULL AUTO_INCREMENT,
  `AdiSoyadi` char(50) NOT NULL,
  `kullaniciAdi` char(50) NOT NULL,
  `bolumID` int(11) NOT NULL,
  `sifre` varchar(32) NOT NULL,
  `yetki` int(11) DEFAULT NULL,
  PRIMARY KEY (`kullaniciID`),
  KEY `bolumID` (`bolumID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin5;

--
-- Tablo döküm verisi `kullanici`
--

INSERT INTO `kullanici` (`kullaniciID`, `AdiSoyadi`, `kullaniciAdi`, `bolumID`, `sifre`, `yetki`) VALUES
(1, 'Admin Alp', 'alp', 1, 'alp', 1),
(7, 'Yekta Parlak', 'yekta', 1, 'yekta', 1),
(8, 'Şeyma Duman', 'şey', 1, 'şey', 1),
(10, 'Berna Sağlam', 'berna', 1, 'berna', 1),
(11, 'Nuri Bilen', 'nuri', 2, 'nuri', 0),
(12, 'Halime Ermiş', 'halime', 3, 'halime', 0),
(13, 'Melda Şen', 'mel', 3, 'mel', 1),
(15, 'Mehmet Yılmaz', 'meh', 2, 'meh', 1),
(16, 'Ahmet Yıldırım', 'ahm', 1, 'ahm', 0),
(17, 'Melih Vural', 'melih', 2, 'melih', 0),
(18, 'Ayşe Korkmaz', 'ayse', 3, '12345', 0),
(19, 'Berra Demir', 'berra', 1, 'berra', 0),
(20, 'Behlül Sarar', 'behl', 1, 'behl', 1),
(21, 'Seda Gürpınar', 'seda', 2, 'seda', 0),
(22, 'Hakan Yılmaz', 'hak', 1, 'hak', 0),
(25, 'Elif Selvi', 'elif', 2, 'elif', 0),
(27, 'Ayşe Ortanca', 'Ayşe', 1, 'ayse', 0),
(28, 'Ahmet Saylan', 'ahmet', 1, 'ahmet', 0),
(29, 'Fadime Nur Gözüpek', 'fadime', 1, 'fadime', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullaniciders`
--

DROP TABLE IF EXISTS `kullaniciders`;
CREATE TABLE IF NOT EXISTS `kullaniciders` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `dersID` int(11) NOT NULL,
  `kullaniciID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `dersID` (`dersID`),
  KEY `kullaniciID` (`kullaniciID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin5;

--
-- Tablo döküm verisi `kullaniciders`
--

INSERT INTO `kullaniciders` (`ID`, `dersID`, `kullaniciID`) VALUES
(1, 2, 7),
(4, 8, 12),
(10, 2, 19),
(12, 1, 19),
(13, 2, 20),
(17, 1, 20),
(20, 9, 21),
(21, 4, 10),
(22, 4, 19),
(23, 5, 19),
(24, 9, 25),
(25, 2, 27),
(26, 1, 27),
(27, 1, 28),
(28, 4, 28),
(29, 1, 29),
(30, 4, 29);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kulllanicikayitdurum`
--

DROP TABLE IF EXISTS `kulllanicikayitdurum`;
CREATE TABLE IF NOT EXISTS `kulllanicikayitdurum` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `kullaniciID` int(11) NOT NULL,
  `dersID` int(11) NOT NULL,
  `kayitAnahtariID` int(11) NOT NULL,
  `durum` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `dersID` (`dersID`),
  KEY `kullaniciID` (`kullaniciID`),
  KEY `kayitAnahtariID` (`kayitAnahtariID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin5;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `dersdosya`
--
ALTER TABLE `dersdosya`
  ADD CONSTRAINT `dersdosya_ibfk_1` FOREIGN KEY (`dersID`) REFERENCES `dersler` (`dersID`);

--
-- Tablo kısıtlamaları `dersicerik`
--
ALTER TABLE `dersicerik`
  ADD CONSTRAINT `dersicerik_ibfk_1` FOREIGN KEY (`dersID`) REFERENCES `dersdosya` (`dersID`);

--
-- Tablo kısıtlamaları `dersler`
--
ALTER TABLE `dersler`
  ADD CONSTRAINT `dersler_ibfk_1` FOREIGN KEY (`bolumID`) REFERENCES `bolumler` (`bolumID`),
  ADD CONSTRAINT `dersler_ibfk_2` FOREIGN KEY (`kullaniciID`) REFERENCES `kullanici` (`kullaniciID`);

--
-- Tablo kısıtlamaları `kayitanahtarlari`
--
ALTER TABLE `kayitanahtarlari`
  ADD CONSTRAINT `kayitanahtarlari_ibfk_1` FOREIGN KEY (`dersID`) REFERENCES `dersler` (`dersID`);

--
-- Tablo kısıtlamaları `kullanici`
--
ALTER TABLE `kullanici`
  ADD CONSTRAINT `kullanici_ibfk_1` FOREIGN KEY (`bolumID`) REFERENCES `bolumler` (`bolumID`);

--
-- Tablo kısıtlamaları `kullaniciders`
--
ALTER TABLE `kullaniciders`
  ADD CONSTRAINT `kullaniciders_ibfk_1` FOREIGN KEY (`dersID`) REFERENCES `dersler` (`dersID`),
  ADD CONSTRAINT `kullaniciders_ibfk_2` FOREIGN KEY (`kullaniciID`) REFERENCES `kullanici` (`kullaniciID`);

--
-- Tablo kısıtlamaları `kulllanicikayitdurum`
--
ALTER TABLE `kulllanicikayitdurum`
  ADD CONSTRAINT `kulllanicikayitdurum_ibfk_1` FOREIGN KEY (`dersID`) REFERENCES `dersler` (`dersID`),
  ADD CONSTRAINT `kulllanicikayitdurum_ibfk_2` FOREIGN KEY (`kullaniciID`) REFERENCES `kullanici` (`kullaniciID`),
  ADD CONSTRAINT `kulllanicikayitdurum_ibfk_3` FOREIGN KEY (`kayitAnahtariID`) REFERENCES `kayitanahtarlari` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
